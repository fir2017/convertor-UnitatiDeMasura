﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace convertorUnitatiDeMasura
{
    public class SistemDeMasura
    {
        public string denumireSistemDeMasura;
        public List<unitatedemasura> listadeunitatidemasura = new List<unitatedemasura>();

    }
}
