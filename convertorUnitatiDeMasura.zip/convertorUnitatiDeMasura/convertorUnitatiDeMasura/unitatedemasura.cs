﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace convertorUnitatiDeMasura
{
    public class unitatedemasura
    {
        public string denumireUnitateDeMasura;
        public string indicativUnitateDeMasura;
        public float valoareUnitateDeMasura;
        public string explicatie;
        public marimeFizica marimeaFizica;

    }
}
