﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace convertorUnitatiDeMasura
{
    public class marimeFizica
    {
        public string marimeaFizicaMasurata;
        public string indicativMarimeFizica;
        public string explicatie;
        public string simbol;
        public string informatii;
    }
}
